=== DeepSeek评论 ===
Contributors: 香山一棵葱 Team
Tags: auto-responder, comments ,artificial-intelligence,api-integration,deepseek ,user-engagement
Requires at least: WordPress 6.5 
Tested up to: WordPress 6.7.2
Stable tag: 1.0.0
License: MIT License
== 描述 ==
本插件为网站提供DeepSeek的评论系统，它会自动调用DeepSeek APIs来恢复访客的评论留言，简单易用。

== 安装 ==
1. 上传本插件 ZIP 文件到 WordPress 后台
2. 前往「插件」菜单激活
3. 在「设置 > 」页面配置 API 密钥

== 更新日志 ==
= 1.0.0 =
* 首次发布基础功能
